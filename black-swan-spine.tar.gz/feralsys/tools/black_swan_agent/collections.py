def defaultdict(*args, **kwargs):
    pass
