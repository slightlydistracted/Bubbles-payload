def load_memory(*args, **kwargs):
    pass

def save_memory(*args, **kwargs):
    pass
