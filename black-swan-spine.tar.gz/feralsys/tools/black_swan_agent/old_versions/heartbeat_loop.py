import asyncio
import json
import os
from datetime import datetime

async def update_prices():
    try:
        with open("simulated_portfolio.json", "r") as f:
            portfolio = json.load(f)
        for position in portfolio:
            if not position.get("sold", False):
                # Fetch new price here (replace with real price fetch)
                position["current_price"] = position.get("current_price", 0)
        with open("simulated_portfolio.json", "w") as f:
            json.dump(portfolio, f, indent=2)
        print("[HEARTBEAT] Updated current prices.")
    except Exception as e:
        print("[ERROR during price update]", e)

async def generate_daily_report():
    try:
        process = await asyncio.create_subprocess_shell(
            "python3 daily_reporter.py"
        )
        await process.communicate()
        print("[HEARTBEAT] Generated daily report.")
    except Exception as e:
        print("[ERROR during daily report]", e)

async def simulate_buy():
    try:
        # Fake buy simulation here
        print("[HEARTBEAT] Simulated buy.")
    except Exception as e:
        print("[ERROR during BUY]", e)

async def simulate_sell():
    try:
        # Fake sell simulation here
        print("[HEARTBEAT] Simulated sell.")
    except Exception as e:
        print("[ERROR during SELL]", e)

async def heartbeat():
    print("[HEARTBEAT]", datetime.utcnow().isoformat())
    await update_prices()
    await generate_daily_report()
    await simulate_buy()
    await simulate_sell()

async def main_loop():
    while True:
        await heartbeat()
        await asyncio.sleep(300)  # 5 minutes

if __name__ == "__main__":
    asyncio.run(main_loop())
