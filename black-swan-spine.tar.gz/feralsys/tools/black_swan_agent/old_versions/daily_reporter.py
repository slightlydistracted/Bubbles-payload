import json
from datetime import datetime

def generate_daily_report():
    try:
        with open("simulated_portfolio.json", "r") as f:
            portfolio = json.load(f)
    except Exception:
        portfolio = []

    try:
        with open("sales_log.json", "r") as f:
            sales_log = json.load(f)
    except Exception:
        sales_log = []

    report = {
        "timestamp": datetime.utcnow().isoformat(),
        "total_investments": len(portfolio),
        "total_sales": len(sales_log),
        "open_positions": [p for p in portfolio if p.get("sold") != True],
        "closed_positions": sales_log,
    }

    with open("daily_report.json", "w") as f:
        json.dump(report, f, indent=2)

    print("[DAILY REPORT GENERATED]")
