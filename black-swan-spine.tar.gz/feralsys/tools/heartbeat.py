import os, json, random, datetime

memory_dir = os.path.expanduser("~/feralsys/memory")
logs_dir = os.path.expanduser("~/feralsys/logs")

def think():
    thought = {
        "time": str(datetime.datetime.now()),
        "thought": "Mutation seed " + str(random.randint(1000, 9999)),
    }
    return thought

def save_thought(thought):
    memory_file = os.path.join(memory_dir, "thoughts.json")
    if not os.path.exists(memory_file):
        with open(memory_file, "w") as f:
            json.dump([], f)
    with open(memory_file, "r+") as f:
        data = json.load(f)
        data.append(thought)
        f.seek(0)
        json.dump(data, f, indent=2)

def log_heartbeat(thought):
    log_file = os.path.join(logs_dir, "heartbeat.log")
    with open(log_file, "a") as f:
        f.write(str(thought) + "\n")

if __name__ == "__main__":
    thought = think()
    save_thought(thought)
    log_heartbeat(thought)
    print("FERALSYS heartbeat: ", thought)
