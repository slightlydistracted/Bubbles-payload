import os, json, random

chaos_dir = os.path.expanduser("~/feralsys/chaos")

# Simple survival logic
def evaluate_mutation(mutation):
    if "speed+" in mutation.get("effect", "") or "chaos++" in mutation.get("effect", ""):
        return True  # Good mutation
    if "logic-" in mutation.get("effect", ""):
        return False  # Bad mutation
    # Random survival chance for neutral mutations
    return random.choice([True, False])

def prune():
    files = [f for f in os.listdir(chaos_dir) if f.startswith("mutation_") and f.endswith(".json")]
    for file in files:
        path = os.path.join(chaos_dir, file)
        try:
            with open(path, "r") as f:
                mutation = json.load(f)
            if not evaluate_mutation(mutation):
                os.remove(path)
                print(f"Pruned: {file}")
            else:
                print(f"Survived: {file}")
        except Exception as e:
            print(f"Error processing {file}: {e}")

if __name__ == "__main__":
    prune()
