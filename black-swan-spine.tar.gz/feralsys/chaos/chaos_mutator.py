import os, random, datetime, json

chaos_dir = os.path.expanduser("~/feralsys/chaos")
os.makedirs(chaos_dir, exist_ok=True)

MAX_MUTATIONS = 1000
VALID_EFFECTS = {"speed+", "logic+", "risk-", "caution+", "aggression-", "mutation+"}
LOG_FILE = os.path.join(chaos_dir, "chaos_log.txt")

def spawn_mutation():
    return {
        "time": str(datetime.datetime.now()),
        "mutation": "Behavioral tweak " + str(random.randint(1, 9999)),
        "effect": random.choice(list(VALID_EFFECTS))
    }

def save_mutation(mutation):
    filename = f"mutation_{random.randint(1000, 9999)}.json"
    with open(os.path.join(chaos_dir, filename), "w") as f:
        json.dump(mutation, f, indent=2)

def validate_mutation(file_path):
    try:
        with open(file_path) as f:
            data = json.load(f)
        return (
            isinstance(data, dict)
            and "effect" in data
            and data["effect"] in VALID_EFFECTS
        )
    except:
        return False

def prune_mutations():
    files = sorted([
        f for f in os.listdir(chaos_dir)
        if f.startswith("mutation_") and f.endswith(".json")
    ], key=lambda x: os.path.getmtime(os.path.join(chaos_dir, x)))

    kept = 0
    for f in files:
        full_path = os.path.join(chaos_dir, f)
        if validate_mutation(full_path):
            kept += 1
            if kept > MAX_MUTATIONS:
                os.remove(full_path)
        else:
            os.remove(full_path)

def log(message):
    with open(LOG_FILE, "a") as logf:
        logf.write(f"[{datetime.datetime.now()}] {message}\n")

if __name__ == "__main__":
    mutation = spawn_mutation()
    save_mutation(mutation)
    log(f"Spawned: {mutation}")
    prune_mutations()
